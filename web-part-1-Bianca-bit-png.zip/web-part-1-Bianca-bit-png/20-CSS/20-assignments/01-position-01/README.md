# Assignment

Please create the design below by adding HTML/CSS using files within the `app` folder. Please commit and push your progress regularly to the GitHub repository. When finished, please turn in the assignment in Teams. You do not need to upload any content to Teams; committing and pushing to GitHub is sufficient.

Have fun!

![assignment](static/image.png)
