# Assignment

Please create a design that imitates the look of

https://www.mercedes-benz.at

Download all the required images directly from the website.

Have fun!
