# Tools

Following are some links to useful tools for web development

## Can I use

A site to lookup browser compatibility for web technologies

- [Can I use](https://caniuse.com)

## Generators for different web aspects

- [Font](https://html-css-js.com/css/generator/font/)
- [Text Shadow](https://html-css-js.com/css/generator/text-shadow/)
- [Box Shadow](https://html-css-js.com/css/generator/box-shadow/)
- [Gradient](https://html-css-js.com/css/generator/gradient/)
- [Flex Box](https://flexbox.malven.co)
- [Grid](https://grid.malven.co)
